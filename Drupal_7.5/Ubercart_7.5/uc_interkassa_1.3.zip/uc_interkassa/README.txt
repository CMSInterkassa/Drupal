Модуль разработан в компании GateOn предназначен для CMS Drupal 7 + Ubercart 3
Сайт разработчикa: www.gateon.net
E-mail: www@smartbyte.pro
Версия: 1.2